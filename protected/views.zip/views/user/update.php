




<?php $this->renderPartial('_form', array('model'=>$model)); ?>