<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h3>Welcome to <?php echo Yii::app()->name; ?></h3>