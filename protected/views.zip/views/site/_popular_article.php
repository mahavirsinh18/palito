<div class="item">
	<?php

	$id = Yii::app()->user->id;
	$bookmark = Bookmark::model()->find('user_id='.$id.' and article_id='.$data->id);
	if(!$bookmark)
	{
		?>
		<a href="javascript:void(0)" class="book" data-id="<?php echo $data->id ?>">
			<div class="bookmarkbtn">
				<input type="checkbox" class="remove" />
				<span></span>
			</div>
		</a>
		<?php
	}
	else
	{
		?>
		<a href="javascript:void(0)" class="book" data-id="<?php echo $data->id ?>">
			<div class="bookmarkbtn">
				<input type="checkbox" class="remove" checked="checked" disabled="disabled" />
				<span></span>
			</div>
		</a>
		<?php
	}

	?>
	
	<div class="image">
		<a href="<?php echo Yii::app()->createUrl('site/details',array('id'=>$data->id));?>">
			<?php echo CHtml::image(Yii::app()->request->baseUrl . "/uploads/" . $data->article_image , "this is alt tag of image");?>
		</a>
	</div>

	<div class="text">
		<h4>
			<a href="<?php echo Yii::app()->createUrl('site/details',array('id'=>$data->id));?>">
				<?php echo $data->article_name ?>
			</a>
			<?php
				$id = Yii::app()->user->id;
				$liked = Liked::model()->find('user_id='.$id.' and article_id='.$data->id);
				if(!$liked)
				{
					?>
					<span>
						<button class="likebtn" style="border: none; border-radius: 50%;" data-id="<?php echo $data->id ?>">
							<i class="thumb fa fa-thumbs-o-up"></i>
						</button>
					</span>
					<?php
				}
				else
				{
					?>
					<span>
						<button class="likebtn" style="border: none; border-radius: 50%;" data-id="<?php echo $data->id ?>" disabled="disabled">
							<i class="thumb fa fa-thumbs-up"></i>
						</button>
					</span>
					<?php
				}
			?> 
			<!-- <span><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span> -->
		</h4>
		<!-- <p class="desc"><?php echo $string = substr($data->description,0,250); ?></p> -->
		<p class="desc"><?php echo $data->description; ?></p>
	</div>
</div>