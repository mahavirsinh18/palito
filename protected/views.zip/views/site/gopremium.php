<?php
	$user_data = array();
	if(!Yii::app()->user->isGuest){
		$user_id = Yii::app()->user->id;	
		$user_data = User::model()->findByPk($user_id);
	}
?>
<style type="text/css">
    .box-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
       
    }
    .box-dismissable, .box-dismissible {
        padding-right: 35px;
    }
    .box {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 4px;
    }
    .box-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeeba;
         font-size: 18px;
    }
    .stripe-button-el{
    	display: none;
    }
</style>
<?php
/* @var $this SiteController */
$this->pageTitle=Yii::app()->name;
?>
<!-- <h3>Welcome to <?php echo Yii::app()->name; ?></h3> -->
<div class="row wrapper border-bottom white-bg page-heading">
	
	<div class="section grid go-premium-section">
		<h2 class="title">Go Premium</h2>
		<div class="white-box">
			<div class="row">
				<div class="col-sm-6">
					<img src="<?php echo Yii::app()->request->baseUrl;?>/img/go-premium-img.png" />
				</div>
				<div class="col-sm-6">
					<div class="text">
					<p>Lorem ipsum dolor sit amet, perci pitur sadip scing ea mea. Vel ex apeirian definitionem, in vis duis sanctus appellantur.</p>
					<p><a href="javascript:void(0)" class="btn btn-primary" id="checkbtn">Checkout</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<form method="POST">
	<script
		src="https://checkout.stripe.com/checkout.js"
		class="stripe-button"
		data-key="pk_test_s0dN2EsNG62WQZpcMNZ8IPL900Ptyv2jCC"
		data-amount="100"
		data-name="Palito">
	</script>
</form>

<script>
	$("#checkbtn").click(function(){
		$(".stripe-button-el").trigger("click");
	});
</script>